/* The most useful C program known to man.  */
static int
do_test (void)
{
  return 0;
}

#include <support/test-driver.c>
