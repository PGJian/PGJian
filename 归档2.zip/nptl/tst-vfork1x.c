#include <posix/tst-vfork1.c>
