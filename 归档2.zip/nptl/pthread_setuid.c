#define SINGLE_THREAD
#define __setuid pthread_setuid_np
#include <setuid.c>
