#include "../elf/tst-execstack-mod.c"
