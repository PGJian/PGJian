#define NOT_CONSISTENT 1
#include "tst-robust1.c"
