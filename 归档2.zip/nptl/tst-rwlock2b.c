#define TYPE PTHREAD_RWLOCK_PREFER_WRITER_NP
#include "tst-rwlock2.c"
