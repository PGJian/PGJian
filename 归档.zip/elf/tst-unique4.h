// BZ 12511
template<int N>
struct S
{
  static int i;
  static const int j;
};
